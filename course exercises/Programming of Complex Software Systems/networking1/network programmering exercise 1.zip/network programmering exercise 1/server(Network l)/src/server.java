import java.net.*;
import java.io.*;
public class server {

	public static void main(String[] args) throws IOException
	{
		  try {
		ServerSocket ss = new ServerSocket(8000);
		Socket s =  ss.accept();
		
		System.out.println("client connected");

		DataInputStream fromClient = new DataInputStream(
		        s.getInputStream());
		      DataOutputStream toClient = new DataOutputStream(
		        s.getOutputStream());
		      while (true) {
			        // Receive annual interest rate from the client
			        double annualInterestRate = fromClient.readDouble();

			        // Receive number of years f6hhurom the client
			        int numOfYears = fromClient.readInt();

			        // Receive loan from the client
			        double loanAmount = fromClient.readDouble();

			        // Compute monthly payment and total payment
			        double monthlyInterestRate = annualInterestRate / 1200;
			        double monthlyPayment = loanAmount * monthlyInterestRate / (1 - (1 / Math.pow(1 + monthlyInterestRate, numOfYears * 12)));
			        
			        double totalPayment = monthlyPayment * numOfYears * 12;
			        // Send results back to the client
			        toClient.writeDouble(monthlyPayment);
			        toClient.writeDouble(totalPayment);

			        System.out.println("Annual Interest Rate: " + annualInterestRate +
			          "\nNumber of Years: " + numOfYears + "\nLoan Amount: " +
			          loanAmount + "\n");
			        System.out.println("monthlyPayment: " + monthlyPayment + " " +
			          "\ntotalPayment: " + totalPayment + '\n');
			        
			      }
			    }
			    catch(IOException e) {
			      System.err.println(e);
			    }
	}
}
