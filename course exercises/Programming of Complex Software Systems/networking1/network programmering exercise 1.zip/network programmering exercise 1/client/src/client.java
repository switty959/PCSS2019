import java.net.*;
import java.util.Scanner;
import java.io.*;
public class client {

	public static void main(String[] args) throws IOException
	{
		Scanner input = new Scanner(System.in);
		boolean connect = true;
		
		
		


		String[] commandLines = {"new","setInterestRate","setYear","loanAmount","infoBank"};
		
		try
		{
			Socket s = new Socket("localhost",8000);
			
			
			DataInputStream fromServer = new DataInputStream(s.getInputStream());
			
			DataOutputStream toServer = new DataOutputStream(s.getOutputStream());
			
			System.out.println("Welcome to the bank server!");
			System.out.println("are you an new user type 'new'");
			System.out.println("otherwise type one of the following commands");
			System.out.println("setInterestRate");
			System.out.println("setYear");
			System.out.println("loanAmount");
			System.out.println("infoBank");
			while(connect)
			{
				
					if(input.next().equals(commandLines[0]))
					{
						 // Enter annual interest rate
						  System.out.print("Enter annual interest rate, for example, 8,25: ");
						  double annualInterestRate = input.nextDouble();
						  
						  // Enter number of years
						  System.out.print("Enter number of years as an integer: ");
						  int numOfYears = input.nextInt();
						  
						  // Enter loan amount
						  System.out.print("Enter loan amount, for example, 120000,95: ");
						  double loanAmount = input.nextDouble();  
						  	
						 // Send the annual interest rate to the server
						  toServer.writeDouble(annualInterestRate);

					 // Send the number of years to the server
						  toServer.writeInt(numOfYears);

					 // Send the loan amount to the server
						  toServer.writeDouble(loanAmount);

						  toServer.flush();

					 // Get monthly payment from the server
					 double monthlyPayment = fromServer.readDouble();

					// Get total payment from the server
					double totalPayment = fromServer.readDouble();

					System.out.println("Annual Interest Rate: " + annualInterestRate +
					        "\nNumber of Years: " + numOfYears + "\nLoan Amount: " +
					        loanAmount + "\n");
					System.out.println("monthlyPayment: " + monthlyPayment + " " +
					        "\ntotalPayment: " + totalPayment + '\n');
					//Exit or continue with a new set of values
					System.out.print("Type yes to continue with a new set of value or no to stop: ");
					}
					if(input.next().equals(commandLines[1]))
					{
						System.out.println("Enter annual interest rate, for example, 8,25: ");
						  double annualInterestRate = input.nextDouble();
						  toServer.flush();
						  System.out.println("your annaual interest rate is : " + annualInterestRate);
					}
					if(input.next().equals(commandLines[2]))
					{
						System.out.println("Enter the number of years you have been part of this bank ");
						  int numOfYears = input.nextInt();
						  toServer.flush();
						  System.out.println("you have have been in this bank since : " + (2019-numOfYears));
					}
					if(input.next().equals(commandLines[3]))
					{
						System.out.println("how much will you like to loan? ");
						double loanAmount = input.nextDouble();
						  toServer.flush();
						  System.out.println("the amount you would like to loan  : " + loanAmount);
					}
					
					
				}
		
		}
		catch(IOException ex) 
		{
		System.out.println(ex.toString());
		}
			
	}
	
	
}
