public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game game =new Game("Game",640,360);
		game.start();
		
	}

}
