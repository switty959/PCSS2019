import java.awt.Graphics;
import java.awt.image.BufferStrategy;

public class Game implements Runnable {

	private int width,height;
	public String title;
	private boolean running = false;
	private Thread thread;
	private display display;
	
	private BufferStrategy bs;
	private Graphics g;
	
	public Game(String newTitle, int newWidth,int newHeight)
	{

		width = newWidth;
		height = newHeight;
		title = newTitle;

		
	}
	
	private void init()
	{
		new display(title,width,height);
	}
	
	private void update()
	{
		
	}
	
	private void render()
	{
		bs = display.getCanvas().getBufferStrategy();
		if(bs == null) 
		{
			display.getCanvas().createBufferStrategy(3);
			return;
		}
		g = bs.getDrawGraphics();
		//draw here
		
		g.fillRect(0,0, width, height);
				
		//end drawing
		bs.show();
		g.dispose();
	}
	
	
	public void run()
	{
		init();
		while(running)
		{
			update();
			render();
		}
		stop();
	}
	public synchronized void start()
	{
		if(running)
		{
			return;
		}
		running = true;
		thread = new Thread(this);
		thread.start();
	}
	public synchronized void stop()
	{
		if(!running)
		{
			return;
		}
		running = false;
		try
		{
			thread.join();
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}
}
