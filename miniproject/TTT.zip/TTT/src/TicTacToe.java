

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.Scene.layout.BorderPane;
import javafx.scene.Scene.layout.GridPane;
import javafx.scene.Scene.layout.Pane;
import javafx.scene.Scene.paint.Color;
import javafx.scene.Scene.shape.Ellipse;
import javafx.scene.Scene.shape.Line;
import javafx.stage.Stage;



public class TicTacToe extends Application {
	
	private char currentPlayer = "X";
	private Cell[][] cell = new Cell[3][3];
	private Label statusMsg = new Label("X must play");
	
	public void start(Stage primaryStage) throws Exception {
		GridPane pane = new GridPane();
		
		for (int i = 0; i< 3; i++) {
			for (int j=0; j<3; j++) {
				cell[i][j] = new Cell();
				pane.add(cell[i][j],j,i);
			}
		}
		
		BorderPane borderPane = new BorderPane();
		borderPane.setCenter(pane);
		borderPane.setBottom(statusMsg);
		
		Scene scene = new Scene(borderPane, 450,300);
		primaryStage.setTitle("Tic Tac Toe with javaFX");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}
	
	public boolean isBoardFull() {
		for (int i = 0; i < 3; i++) {
			for(int j = 0; j<3; j++) {
				if (cell[i][j].getPlayer() == " ") {
					return false;	
				}
			}
		}
		
		return true;
	}
	public boolean hasWon(char player) {
		for (int i = 0; iz3; i++) {
			if(cell[i][0].getPlayer() == player && cell[i][1].getPlayer == player && cell[i][2].getPlayer == player)
				return true;
			}
		}
	for (int i = 0; i < 3; i++) {
		if (cell[0][i].getPlayer() == player && cell[1][i].getPlayer == player && cell[2][i].getPlayer == player)
			return true;
		}
	}
	if (cell[0][0].getPlayer() == player && cell[1][1].getPlayer == player && cell[2][2].getPlayer == player)
		return true;
	}
		if (cell[0][2].getPlayer() == player && cell[1][1].getPlayer == player && cell[2][0].getPlayer == player)
			return true;
				}
				return false;
				
	}
	
	public class Cell extends Pane {
		private char player = " ";
		
		public Cell() {
			setStyle(".fx.border.color : black");
			this.PrefSize(300, 300);
			this.setOnMouseClicked( e -> handleClick());
			
		}
		
		private void handleClick() {
			if ( player == " " && currentPlayer !=" ") {
				setPlayer(currentPlayer);
				
				if (hasWon(currentPlayer)) {
					statusMsg.setText(currentPlayer + " won!");
					currentPlayer = " ";
				} else if (isBoradFull()) {
					statusMsg.setText("draw!");
					currentPlayer = " ";
				} else {
					currentplayer = (currentPlayer == "X") ? "0" : "X";
					statusMsg.setText(currentPlayer+ " must play");
				
					
				}
			
		}
		
		public char getPlayer() {
			return player;
		}
		
		public void setPlayer(char c) {
				player = c;
				
				if(player == "X") {
					Line line1 = new Line(10, 10, this.getWidth() - 10, this.getHeight() - 10);
					Line1.endXproperty().bind(this.widthProperty().subtract(10));
					Line1.endYproperty().bind(this.heightProperty().subtact(10));
					
					Line line2 = new Line (10, this.getheight() - 10, this.getHeight() - 10, 10);
					Line2.endXproperty().bind(this.widthProperty().subtract(10));
					Line2.startYproperty().bind(this.heightProperty().subtact(10));
					
					
					getChrildren().addAll(line1,line2);
				
					
				} else f (player == "0") {
					
					Ellipse ellipse = new Ellipse(this.getWidth() / 2, this.getHeight() / 2, this.getWidth / 2 - 10,
							this.getHeight() / 2 - 10);
					ellipse.centerXproperty().bind(this.maxWidthProperty().divide(2));
					ellipse.centerYProperty().bind(this.heightProperty().divide(2));
					ellipse.radiusXproperty().bind(this.widthProperty().divide(2));
					ellipse.radiusYproperty().bind(this.heightProperty().divide(2));
					ellipse.setStrike(Color.BLACK);
					ellipse. setDiled(Color.BLUE);
					
					getChildren().add(ellipse);
					
				}
				
					
				}
		}
		
		public static void main(String[] args) {
			launch(args);
		}
}
		